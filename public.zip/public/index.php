<?php
require_once '../config/config.php';
require_once '../src/vendor/autoload.php';
use Src\Classes\ClassRoutes;

//$pagina=new App\Dispatch();
include '../app/controller/ControllerEmail.php';


